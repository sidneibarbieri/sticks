# Canonical Source Provenance

This directory became the canonical STICKS development root on
2026-07-27T20:02:35Z.

## Imported State

The source came from a legacy local development workspace. The private
migration ledger retains the original repository, commit, and file hashes.

The migration included the complete filtered working tree, including tracked
modifications and untracked source files. It excluded virtual environments, Vagrant
state, Python caches, and `.DS_Store`. Origin and destination manifests matched after
these exclusions.

The historical `research/sticks/sticks-main/` tree remains available for comparison,
but it is not a development source.

Exact migration paths and file-level hashes remain in that private ledger.

## Rule

Do not synchronize changes back to the migration source. Publish only after tests,
reviewer-path validation, sanitization, and an explicit release decision.
