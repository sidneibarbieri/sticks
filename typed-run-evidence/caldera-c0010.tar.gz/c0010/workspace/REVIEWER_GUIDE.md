# Reviewer Guide

## Primary path

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash run_review_check.sh
```

The gate regenerates every registered record, verifies the pinned SHA-256
manifest, audits claim-to-evidence chains, checks the public surface, and runs
the test suite. A failure is terminal; no step is masked.

Inspect `release/claims/verification.json`,
`release/claims/evidence_sha256.json`, `release/experiments/`, and
`release/paper_macros.tex` after the run.

## Manuscript audit

```bash
PAPER_DIR=../paper bash run_review_check.sh
```

This also rejects unregistered references, omitted registered properties,
blocked claims, forbidden wording, and known unsupported legacy results.

## Secondary path

`bash run_review_check.sh --legacy` runs the retained infrastructure-era
measurement check. It is not part of the primary claim contract.
