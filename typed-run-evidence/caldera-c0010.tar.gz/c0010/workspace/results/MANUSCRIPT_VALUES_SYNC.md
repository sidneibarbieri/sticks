# Manuscript Values Sync

## paper2

- Status: `blocked`
- Macros written: `0`
- Details: Paper 2 contains macros without canonical source in measurement/sut/scripts/results/todo_values_latex.tex that are still used in main.tex: campaignCoveragePct, campaignCoverageUnusedPct, campaignTechniqueCount, intrusionSetCoveragePct, intrusionSetEmptyPct, intrusionSetTechAvg, intrusionSetTechRefs, intrusionSetTechniqueCount, intrusionSetWithTechniquesPct, lcsLengthMax, lcsLengthMean, lcsLengthMedian, nAttackPatternObjects, nCampaigns, nIntrusionSets, nIntrusionSetsEmpty, nIntrusionSetsWithTechniques, nPlatformAgnosticTechniques, nRelationships, nTechniquesAnalysis, nTranslatableTechniques, silhouetteBaselineMean, silhouetteBaselineStd, silhouetteScore, topTechniqueId, topTechniqueInCampaigns, topTechniqueLabel, topTechniquePct
