# Paper 1 Appendix Provenance

- Bundle: `data/stix/enterprise-attack.json`
- Active Enterprise attack-patterns: `691`

## Automation-Relevant Field Population

- `kill_chain_phases`: present `691`, non-empty `691`
- `x_mitre_platforms`: present `691`, non-empty `691`
- `x_mitre_system_requirements`: present `0`, non-empty `0`
- `x_mitre_detection`: present `691`, non-empty `0`
- `x_mitre_data_sources`: present `0`, non-empty `0`
- `x_mitre_permissions_required`: present `0`, non-empty `0`

## Non-Sequential Campaign Itemset Support

- Size `1`: max support `28` (54.9%), example `T1105`
- Size `2`: max support `17` (33.3%), example `T1105, T1588.002`
- Size `3`: max support `10` (19.6%), example `T1105, T1190, T1588.002`
- Size `4`: max support `7` (13.7%), example `T1005, T1053.005, T1059.003, T1071.001`
- Size `5`: max support `6` (11.8%), example `T1005, T1033, T1059.003, T1071.001, T1588.002`

## STICKS Execution Breakdown

- `0.c0011`: 11/11 (100.0%), infra=``
- `0.shadowray`: 10/10 (100.0%), infra=`qemu`
