# Host Leakage Audit

- Generated at: `2026-10-10T02:30:18.925155`
- Campaigns audited: `14`
- Campaigns with evidence: `2`
- Campaigns with host leakage in latest evidence: `1`
- Leaked steps in latest evidence: `2`

This scan detects recognized macOS markers and explicit local-host declarations
in retained runner summaries. Absence of a marker does not prove SUT execution.

## Campaign Status

| Campaign | Evidence | Host Leakage | Leaked Steps |
|---|---:|---:|---:|
| 0.apt41_dust | no | not assessed | 0 |
| 0.apt41_dust_full | no | not assessed | 0 |
| 0.c0010 | no | not assessed | 0 |
| 0.c0011 | yes | no | 0 |
| 0.c0012 | no | not assessed | 0 |
| 0.c0013 | no | not assessed | 0 |
| 0.c0015 | no | not assessed | 0 |
| 0.c0017 | no | not assessed | 0 |
| 0.c0026 | no | not assessed | 0 |
| 0.costaricto | no | not assessed | 0 |
| 0.operation_midnighteclipse | no | not assessed | 0 |
| 0.outer_space | no | not assessed | 0 |
| 0.salesforce_data_exfiltration | no | not assessed | 0 |
| 0.shadowray | yes | yes | 2 |

## Detailed Findings

### 0.shadowray

- Latest summary: `release/evidence/0.shadowray_20260407_173127/summary.json`
- `T1027.013` (success): declared_local_host
- `T1068` (success): declared_local_host
