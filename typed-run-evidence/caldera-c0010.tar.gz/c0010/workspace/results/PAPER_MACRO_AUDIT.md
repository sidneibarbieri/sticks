# Paper Macro Audit

- Generated at: `2026-04-03T12:31:06.544450`

## Paper 1

- Defined macros in `values.tex`: `40`
- Macros both defined and used in `main.tex`: `28`
- Sample used macros: `campaignCoveragePct, campaignCoverageUnusedPct, campaignTechniqueCount, intrusionSetCoveragePct, intrusionSetEmptyPct, intrusionSetTechAvg, intrusionSetTechRefs, intrusionSetTechniqueCount, intrusionSetWithTechniquesPct, lcsLengthMax, lcsLengthMean, lcsLengthMedian, nAttackPatternObjects, nCampaigns, nIntrusionSets, nIntrusionSetsEmpty, nIntrusionSetsWithTechniques, nPlatformAgnosticTechniques, nRelationships, nTechniquesAnalysis`

## Paper 1 Macro Provenance

- Sync status: `fully_generator_backed`
- Generator source: `sticks-docker/measurement/scripts/analyze_campaigns.py`
- Generator macro count: `40`
- Generator-backed macros in Paper 1 values: `40`
- Generator-backed macros used in manuscript: `28`
- Manuscript-used macros without generator backing: `0`

## Paper 2

- Defined macros in `values.tex`: `118`
- Macros both defined and used in `main.tex`: `118`

## Paper 2 vs Measurement Pipeline

- Measurement macro count: `118`
- Paper 2 macro count: `118`
- Macros present in Paper 2 but absent from measurement output: `0`
- Macros present in measurement output but absent from Paper 2: `0`

## Paper 2 Macro Provenance

- Sync status: `measurement_backed`
- Measurement-backed macros in Paper 2 values: `118`
- Measurement-backed macros used in manuscript: `118`
- Manuscript-only macros in Paper 2 values: `0`
- Manuscript-only macros used in manuscript: `0`
- Measurement source: `measurement/sut/scripts/results/todo_values_latex.tex`
- Manuscript source: `manuscript/paper2/results/values.tex`

## Executable Subset Macros

- `results/values.tex` tracks the executable published subset, not the Paper 2 measurement surface.
- Executable-subset macro count: `9`
- Overlap with Paper 1 values: `0`
- Overlap with Paper 2 values: `0`
