# Paper Measurements

- Generated at: `2026-10-10T02:30:18.984387`
- Legacy campaigns in sticks-docker: `8`
- Legacy campaigns published in STICKS: `8`
- Legacy campaigns with SUT profile: `8`
- Legacy campaigns whose latest runner summary reports zero failed techniques: `1`
- Legacy campaigns with a summary-bound host-leakage audit: `1`
- Bound audits reporting no host leakage: `0`
- Legacy technique coverage rate: `100.0%`
- Legacy exact technique matches: `0.apt41_dust, 0.c0010, 0.c0026, 0.costaricto, 0.operation_midnighteclipse, 0.outer_space, 0.salesforce_data_exfiltration, 0.shadowray`

Runner outcomes do not certify independently observed effects or historical mechanism fidelity.
An absent or unbound host-leakage audit is not a clean result.

## Legacy Campaign Matrix

| Docker | STICKS | Published | SUT | Exact Match | Legacy Coverage | Latest Success | MITRE Clean | Host Leakage |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| apt41_dust | 0.apt41_dust | yes | yes | yes | 100.0% | none | yes | not assessed |
| c0010 | 0.c0010 | yes | yes | yes | 100.0% | none | yes | not assessed |
| c0026 | 0.c0026 | yes | yes | yes | 100.0% | none | yes | not assessed |
| costaricto | 0.costaricto | yes | yes | yes | 100.0% | none | yes | not assessed |
| operation_midnighteclipse | 0.operation_midnighteclipse | yes | yes | yes | 100.0% | none | yes | not assessed |
| outer_space | 0.outer_space | yes | yes | yes | 100.0% | none | yes | not assessed |
| salesforce_data_exfiltration | 0.salesforce_data_exfiltration | yes | yes | yes | 100.0% | none | yes | not assessed |
| shadowray | 0.shadowray | yes | yes | yes | 100.0% | 10/10 (100.0%) | yes | yes |