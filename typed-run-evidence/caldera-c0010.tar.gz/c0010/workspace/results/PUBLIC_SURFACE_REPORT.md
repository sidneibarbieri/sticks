# Public Surface Report

- Status: `clean`

## Missing Required Paths

- None

## Sensitive Paths Present

- None

## Forbidden Staged Paths Present

- None

## Forbidden Text Hits

- None

## Sensitive Text Hits

- None

## Sensitive Files Present

- None

## README Metric Mismatches

- None

## Local Runtime Artifacts Present

- None

## Ignored Local Runtime Artifacts

- `.venv`
- `.pytest_cache`
- `__pycache__`
- `src/executors/__pycache__`
- `src/loaders/__pycache__`
- `tests/__pycache__`
- `lab/vagrant/.vagrant`

## Structure Smells Present

- None

## Ignored Structure Smells

- None