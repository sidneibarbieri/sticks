"""Exercise conditional dispatch through native CALDERA using harmless markers.

Requires an already healthy, isolated three-VM laboratory. This diagnostic does
not provision or seal campaign evidence; its caller owns the laboratory teardown.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shlex
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from adapters.caldera_operations import CalderaCommand, CalderaOperations
from contracts.branch_decision import ConditionalExit, ConditionObservation, TruthValue
from runners.conditional_execution import execute_conditional_step


from runners.caldera_lab_bootstrap import (
    guest_command, guest_python, laboratory_transport, deploy_agent, wait_for_agent,
)


def await_link(client: CalderaOperations, operation_id: str, link_id: str) -> dict[str, object]:
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        link = client.link(operation_id, link_id)
        if link.get("finish"):
            if link.get("status") != 0:
                raise RuntimeError("CALDERA link finished unsuccessfully")
            return link
        time.sleep(2)
    raise TimeoutError("CALDERA link did not finish")


def run_cell(lab_root, output, client, operation_id, agent_id, remote_root, state):
    cell = output / state
    cell.mkdir()
    remote_cell = remote_root + "/" + state
    source = f"from pathlib import Path; root=Path({remote_cell!r}); root.mkdir()"
    if state != "unknown":
        source += f"; (root/'condition').write_text({state!r})"
    # The deployed Sandcat agent runs as ubuntu. Only that principal prepares
    # writable cells; read-only observations remain a separate SSH process.
    guest_python(lab_root, "target-linux-1", source, as_user="ubuntu")

    def observe() -> ConditionObservation:
        source = f"""
import json
from pathlib import Path
condition = Path({remote_cell!r}) / 'condition'
print(json.dumps({{'value': condition.read_text() if condition.exists() else 'unknown'}}))
"""
        observation_bytes = guest_python(lab_root, "target-linux-1", source).encode()
        (cell / "observation.json").write_bytes(observation_bytes)
        digest = hashlib.sha256(observation_bytes).hexdigest()
        return ConditionObservation(
            condition_id="service_ready", value=json.loads(observation_bytes)["value"],
            evidence_ref=f"observation.json#sha256={digest}",
        )

    def dispatch(target_id: str) -> None:
        command = CalderaCommand(
            agent_id=agent_id, platform="linux", executor="sh",
            command=f"printf observed > {shlex.quote(remote_cell + '/' + target_id + '.marker')}",
        )
        link_id = client.submit_command(operation_id, command)
        (cell / "submitted.json").write_text(json.dumps({"operation_id": operation_id, "link_id": link_id}))
        link = await_link(client, operation_id, link_id)
        (cell / "link.json").write_text(json.dumps(link, indent=2))

    decision = execute_conditional_step(
        "service_ready", (
            ConditionalExit(condition_id="service_ready", target_id="ready", when_true=True),
            ConditionalExit(condition_id="service_ready", target_id="unready", when_true=False),
        ),
        observe=observe, dispatch=dispatch, decision_path=cell / "decision.json",
    )
    source = f"""
import json
from pathlib import Path
print(json.dumps(sorted(path.name for path in Path({remote_cell!r}).glob('*.marker'))))
"""
    markers = json.loads(guest_python(lab_root, "target-linux-1", source))
    expected_target = {"true": "ready", "false": "unready", "unknown": None}[state]
    expected = [expected_target + ".marker"] if expected_target else []
    (cell / "effect.json").write_text(json.dumps({"markers": markers, "expected": expected}))
    if markers != expected or decision.selected_target_id != expected_target:
        raise RuntimeError("independent target observation differs from the selected branch")
    return {"state": state, "selected": decision.selected_target_id, "markers": markers}


def snapshot_sources(output: Path) -> dict[str, str]:
    source_root = Path(__file__).resolve().parents[1]
    files = (
        "scripts/run_conditional_caldera_conformance.py",
        "src/adapters/caldera_operations.py",
        "src/adapters/caldera_dispatch.py",
        "src/adapters/caldera_command_result.py",
        "src/contracts/branch_decision.py",
        "src/runners/conditional_execution.py",
    )
    digests = {}
    for relative in files:
        destination = output / "source-snapshot" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source_root / relative, destination)
        digests[relative] = hashlib.sha256(destination.read_bytes()).hexdigest()
    (output / "source-sha256.json").write_text(json.dumps(digests, indent=2))
    return digests


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lab-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    source_hashes = snapshot_sources(args.output)
    boots = {
        guest: guest_command(args.lab_root, guest, "cat /proc/sys/kernel/random/boot_id")
        for guest in ("caldera", "attacker", "target-linux-1")
    }
    caldera_commit = guest_command(
        args.lab_root, "caldera",
        "sudo git -C /opt/caldera rev-parse HEAD && sudo git -C /opt/caldera diff --exit-code -- server.py",
    )
    if caldera_commit != "b24f6e7a99cab19cbf417009bda9b9c6c81abc31":
        raise ValueError("CALDERA source differs from the pinned runtime")
    (args.output / "environment.json").write_text(json.dumps({
        "boot_ids": boots, "caldera_commit": caldera_commit,
    }, indent=2))
    group = "sticks-conformance-" + uuid.uuid4().hex
    remote_root = "/tmp/" + group
    transport = laboratory_transport(args.lab_root)
    deploy_agent(args.lab_root, group, remote_root)
    agent_id = wait_for_agent(transport, group)
    client = CalderaOperations(transport)
    operation_id = client.create_operation(group, group)
    try:
        cells = [
            run_cell(args.lab_root, args.output, client, operation_id, agent_id, remote_root, state)
            for state in ("true", "false", "unknown")
        ]
        links = transport("GET", "/operations/" + operation_id + "/links", None)
        (args.output / "operation-links.json").write_text(json.dumps(links, indent=2))
        if len(links) != 2:
            raise ValueError("conformance operation must contain exactly two dispatched links")
        summary = {
            "kind": "benign_local_lab_conformance", "operation_id": operation_id,
            "cells": cells, "source_sha256": source_hashes,
        }
        (args.output / "summary.json").write_text(json.dumps(summary, indent=2))
        print(json.dumps(summary))
    finally:
        client.finish_operation(operation_id)
        operation = transport("GET", "/operations/" + operation_id, None)
        (args.output / "operation.json").write_text(json.dumps(operation, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
