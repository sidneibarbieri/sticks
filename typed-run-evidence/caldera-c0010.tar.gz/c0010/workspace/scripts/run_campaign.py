#!/usr/bin/env python3
"""
STICKS Campaign Wrapper - Direct execution without subprocess.
"""

import os
import sys


def _bootstrap_environment() -> None:
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    os.chdir(project_root)

    # Some runtime observers are shared with the review scripts package.  Keep
    # the project root importable when this file is launched by pathname.
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    src = os.path.join(project_root, "src")
    if src not in sys.path:
        sys.path.insert(0, src)


def main() -> int:
    _bootstrap_environment()

    from executors.registry_initializer import initialize_registry
    from runners.campaign_runner import main as runner_main

    initialize_registry()
    return runner_main()


if __name__ == "__main__":
    raise SystemExit(main())
