#!/usr/bin/env python3
"""
Generate an honest corpus-state report for the published and executable subsets.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
from concretization.execution_audit_binding import bound_host_leakage_audit  # noqa: E402

CAMPAIGNS_DIR = PROJECT_ROOT / "campaigns"
SUT_DIR = PROJECT_ROOT / "data" / "sut_profiles"
EVIDENCE_DIR = PROJECT_ROOT / "release" / "evidence"
PARITY_REPORT = PROJECT_ROOT / "results" / "legacy_parity_report.json"
MITRE_AUDIT = PROJECT_ROOT / "results" / "mitre_metadata_audit.json"
HOST_LEAKAGE = PROJECT_ROOT / "results" / "host_leakage_audit.json"
OUTPUT_DIR = PROJECT_ROOT / "runs" / "corpus-state"
TIMESTAMP_SUFFIX = re.compile(r"\d{8}_\d{6}$")


def display_path(path: Path) -> str:
    try:
        return str(path.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def _load_validation_helper():
    sys.path.insert(0, str(PROJECT_ROOT / "src"))
    from loaders.campaign_loader import validate_campaign_sut_pair  # type: ignore

    return validate_campaign_sut_pair


def evidence_dirs_for_campaign(campaign_id: str) -> list[Path]:
    prefix = f"{campaign_id}_"
    matches: list[Path] = []
    if not EVIDENCE_DIR.exists():
        return matches
    for candidate in EVIDENCE_DIR.iterdir():
        if not candidate.is_dir():
            continue
        if not candidate.name.startswith(prefix):
            continue
        suffix = candidate.name[len(prefix) :]
        if TIMESTAMP_SUFFIX.fullmatch(suffix):
            matches.append(candidate)
    return matches


def latest_summary(campaign_id: str) -> dict | None:
    candidates = evidence_dirs_for_campaign(campaign_id)
    if not candidates:
        return None
    latest_dir = max(candidates, key=lambda path: path.name)
    summary_path = latest_dir / "summary.json"
    if not summary_path.exists():
        return None
    summary_bytes = summary_path.read_bytes()
    summary = json.loads(summary_bytes)
    total = summary.get("total_techniques", 0)
    successful = summary.get("successful", 0)
    return {
        "evidence_dir": display_path(latest_dir),
        "summary_path": display_path(summary_path),
        "summary_sha256": hashlib.sha256(summary_bytes).hexdigest(),
        "evidence_scope": "runner_report_only",
        "total_techniques": total,
        "successful": successful,
        "failed": summary.get("failed", 0),
        "success_rate": successful / total if total else 0.0,
    }


def build_report(host_leakage_path: Path | None = None) -> dict:
    published = sorted(path.stem for path in CAMPAIGNS_DIR.glob("*.json"))
    sut_profiles = {path.stem for path in SUT_DIR.glob("*.yml")}
    validate_campaign_sut_pair = _load_validation_helper()
    parity = json.loads(PARITY_REPORT.read_text()) if PARITY_REPORT.exists() else {}
    mitre = json.loads(MITRE_AUDIT.read_text()) if MITRE_AUDIT.exists() else {}
    audit_path = HOST_LEAKAGE if host_leakage_path is None else host_leakage_path
    host_leakage = json.loads(audit_path.read_text()) if audit_path.exists() else {}

    parity_by_campaign = {
        item["sticks_campaign"]: item for item in parity.get("campaigns", [])
    }
    mitre_by_campaign = {
        item["campaign_id"]: item for item in mitre.get("campaigns", [])
    }
    leakage_by_campaign = {
        item["campaign_id"]: item for item in host_leakage.get("campaigns", [])
    }

    campaign_rows = []
    for campaign_id in published:
        summary = latest_summary(campaign_id)
        leakage_detected, leakage_status = bound_host_leakage_audit(
            leakage_by_campaign.get(campaign_id, {}), summary
        )
        has_sut = campaign_id in sut_profiles
        pair_error = ""
        pair_valid = False
        if has_sut:
            pair_error = validate_campaign_sut_pair(campaign_id) or ""
            pair_valid = pair_error == ""
        row = {
            "campaign_id": campaign_id,
            "published": True,
            "has_sut": has_sut,
            "pair_valid": pair_valid,
            "pair_error": pair_error,
            "has_latest_evidence": summary is not None,
            "latest_execution": summary,
            "mitre_metadata_clean": (
                mitre_by_campaign.get(campaign_id, {}).get("steps_with_missing_metadata", 1)
                == 0
                and mitre_by_campaign.get(campaign_id, {}).get("steps_with_tactic_mismatch", 1)
                == 0
                and mitre_by_campaign.get(campaign_id, {}).get("steps_without_mitre_support", 1)
                == 0
            ),
            "legacy_parity": parity_by_campaign.get(campaign_id),
            "host_leakage_detected": leakage_detected,
            "host_leakage_audit_status": leakage_status,
        }
        campaign_rows.append(row)

    executable_subset = [row for row in campaign_rows if row["has_sut"]]
    evidenced_subset = [row for row in campaign_rows if row["has_latest_evidence"]]
    successful_subset = [
        row
        for row in evidenced_subset
        if row["latest_execution"]
        and row["latest_execution"]["total_techniques"] > 0
        and row["latest_execution"]["failed"] == 0
    ]

    return {
        "generated_at": datetime.now().isoformat(),
        "published_campaigns": len(campaign_rows),
        "executable_campaigns_with_sut": len(executable_subset),
        "campaigns_with_strict_pair_validation": sum(
            1 for row in campaign_rows if row["pair_valid"]
        ),
        "campaigns_with_latest_evidence": len(evidenced_subset),
        "campaigns_with_zero_failed_in_latest_evidence": len(successful_subset),
        "mitre_metadata_clean_campaigns": sum(
            1 for row in campaign_rows if row["mitre_metadata_clean"]
        ),
        "campaigns_without_host_leakage": sum(
            1 for row in evidenced_subset if row["host_leakage_detected"] is False
        ),
        "campaigns_with_bound_host_leakage_audit": sum(
            row["host_leakage_audit_status"] == "bound" for row in campaign_rows
        ),
        "legacy_direct_counterparts": parity.get("mapped_legacy_campaigns", 0),
        "legacy_exact_matches": parity.get("exact_technique_matches", []),
        "legacy_technique_coverage_rate": parity.get(
            "legacy_technique_coverage_rate", 0.0
        ),
        "campaigns": campaign_rows,
    }


def write_markdown(report: dict, output_path: Path) -> None:
    lines = [
        "# Corpus State",
        "",
        f"- Generated at: `{report['generated_at']}`",
        f"- Published campaigns: `{report['published_campaigns']}`",
        f"- Executable campaigns with SUT profile: `{report['executable_campaigns_with_sut']}`",
        f"- Campaign/SUT pairs passing strict validation: `{report['campaigns_with_strict_pair_validation']}`",
        f"- Campaigns with latest evidence: `{report['campaigns_with_latest_evidence']}`",
        f"- Campaigns with zero failed techniques in latest evidence: `{report['campaigns_with_zero_failed_in_latest_evidence']}`",
        f"- Campaigns with clean MITRE metadata audit: `{report['mitre_metadata_clean_campaigns']}`",
        f"- Summary-bound audits reporting no host leakage: `{report['campaigns_without_host_leakage']}`",
        f"- Legacy direct counterparts: `{report['legacy_direct_counterparts']}`",
        f"- Legacy exact technique matches: `{', '.join(report['legacy_exact_matches']) or 'none'}`",
        f"- Legacy technique coverage rate: `{report['legacy_technique_coverage_rate']:.1%}`",
        "",
        "Runner outcomes do not certify independently observed effects or mechanism fidelity.",
        "Absent or unbound host-location audits are not clean results.",
        "Negative audits cover retained markers and declared hosts, not independent isolation proof.",
        "",
        "## Campaign Status",
        "",
        "| Campaign | SUT | Pair Valid | Evidence | Latest Success | MITRE Clean | Host Leakage | Legacy Match |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]

    for row in report["campaigns"]:
        latest = row["latest_execution"]
        latest_rate = (
            f"{latest['successful']}/{latest['total_techniques']} ({latest['success_rate']:.1%})"
            if latest
            else "none"
        )
        legacy = row["legacy_parity"]
        leakage = row["host_leakage_detected"]
        leakage_text = "not assessed" if leakage is None else ("yes" if leakage else "no")
        legacy_match = (
            "exact"
            if legacy and legacy["exact_technique_match"]
            else f"{legacy['legacy_coverage_rate']:.1%}" if legacy else "n/a"
        )
        lines.append(
            f"| {row['campaign_id']} | {'yes' if row['has_sut'] else 'no'} | "
            f"{'yes' if row['pair_valid'] else 'no'} | "
            f"{'yes' if row['has_latest_evidence'] else 'no'} | {latest_rate} | "
            f"{'yes' if row['mitre_metadata_clean'] else 'no'} | "
            f"{leakage_text} | {legacy_match} |"
        )

    invalid_rows = [row for row in report["campaigns"] if row["has_sut"] and not row["pair_valid"]]
    lines.extend(["", "## Validation Exceptions", ""])
    if invalid_rows:
        for row in invalid_rows:
            lines.append(f"- `{row['campaign_id']}`: {row['pair_error']}")
    else:
        lines.append("- None")

    output_path.write_text("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--host-leakage-audit", type=Path, default=HOST_LEAKAGE)
    arguments = parser.parse_args()
    report = build_report(arguments.host_leakage_audit)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    output_json = arguments.output_dir / "corpus_state.json"
    output_markdown = arguments.output_dir / "CORPUS_STATE.md"
    output_json.write_text(json.dumps(report, indent=2))
    write_markdown(report, output_markdown)
    print(f"Wrote {output_json}")
    print(f"Wrote {output_markdown}")


if __name__ == "__main__":
    main()
