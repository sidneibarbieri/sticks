"""Verify retained branch decisions against native links and SSH observations."""

import argparse
import hashlib
import json
from pathlib import Path


EXPECTED_TARGETS = {"true": "ready", "false": "unready", "unknown": None}


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify_sources(root: Path) -> None:
    source_root = (root / "source-snapshot").resolve(strict=True)
    hashes = read_json(root / "source-sha256.json")
    if not hashes:
        raise ValueError("source snapshot is empty")
    for relative_path, expected_hash in hashes.items():
        source = (source_root / relative_path).resolve(strict=True)
        if not source.is_relative_to(source_root):
            raise ValueError("source snapshot reference escapes the evidence directory")
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected_hash:
            raise ValueError(f"source digest differs: {relative_path}")


def verify_cell(root: Path, state: str, target: str | None, links: dict, operation_id: str):
    cell = root / state
    observation_bytes = (cell / "observation.json").read_bytes()
    observation = json.loads(observation_bytes)
    decision = read_json(cell / "decision.json")
    effect = read_json(cell / "effect.json")
    expected_reference = "observation.json#sha256=" + hashlib.sha256(observation_bytes).hexdigest()
    if observation["value"] != state or decision["value"] != state:
        raise ValueError(f"condition value differs for {state}")
    if decision["condition_id"] != "service_ready" or decision["evidence_ref"] != expected_reference:
        raise ValueError(f"decision evidence differs for {state}")
    if decision["selected_target_id"] != target:
        raise ValueError(f"wrong branch selected for {state}")
    markers = [target + ".marker"] if target else []
    if effect["markers"] != markers or effect["expected"] != markers:
        raise ValueError(f"observed target effects differ for {state}")
    if target is None:
        if (cell / "submitted.json").exists() or (cell / "link.json").exists():
            raise ValueError("unknown condition dispatched an action")
        return None
    submitted = read_json(cell / "submitted.json")
    if submitted["operation_id"] != operation_id:
        raise ValueError("link belongs to another operation")
    link = links[submitted["link_id"]]
    if link != read_json(cell / "link.json"):
        raise ValueError("retained link differs from the operation chain")
    if type(link["status"]) is not int or link["status"] != 0 or not link["finish"]:
        raise ValueError("native link did not finish successfully")
    if f"/{state}/{target}.marker" not in link["command"]:
        raise ValueError("native command differs from selected target marker")
    return link["id"]


def verify_conformance(root: Path) -> dict[str, object]:
    verify_sources(root)
    summary = read_json(root / "summary.json")
    operation = read_json(root / "operation.json")
    chain = read_json(root / "operation-links.json")
    environment = read_json(root / "environment.json")
    expected_cells = [
        {"state": state, "selected": target, "markers": [target + ".marker"] if target else []}
        for state, target in EXPECTED_TARGETS.items()
    ]
    if summary.get("kind") != "benign_local_lab_conformance" or summary.get("cells") != expected_cells:
        raise ValueError("summary differs from the three declared conditions")
    if summary.get("source_sha256") != read_json(root / "source-sha256.json"):
        raise ValueError("summary source hashes differ from the source snapshot")
    if operation["id"] != summary["operation_id"] or operation["state"] != "finished":
        raise ValueError("conformance operation was not closed")
    if operation["auto_close"] is not False or not operation["group"].startswith("sticks-conformance-"):
        raise ValueError("operation was not isolated for incremental dispatch")
    if environment["caldera_commit"] != "b24f6e7a99cab19cbf417009bda9b9c6c81abc31":
        raise ValueError("CALDERA revision differs from the pinned runtime")
    if set(environment["boot_ids"]) != {"caldera", "attacker", "target-linux-1"}:
        raise ValueError("three-guest boot evidence is incomplete")
    if len(chain) != 2 or len({link["id"] for link in chain}) != 2:
        raise ValueError("expected exactly two distinct native links")
    links = {link["id"]: link for link in chain}
    selected_links = {
        verify_cell(root, state, target, links, operation["id"])
        for state, target in EXPECTED_TARGETS.items()
    } - {None}
    if selected_links != set(links):
        raise ValueError("operation includes an unexplained action")
    return {"verified": True, "states": list(EXPECTED_TARGETS), "native_links": len(links)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify_conformance(args.evidence)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
