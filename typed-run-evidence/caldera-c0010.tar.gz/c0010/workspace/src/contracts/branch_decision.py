"""Choose an authored exit; the caller validates the observation's evidence."""

from collections.abc import Sequence
from enum import Enum

from pydantic import BaseModel, ConfigDict, model_validator

from contracts.flow_structure import ConditionalExit


class TruthValue(str, Enum):
    TRUE = "true"
    FALSE = "false"
    UNKNOWN = "unknown"


class ConditionObservation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    condition_id: str
    value: TruthValue
    evidence_ref: str | None

    @model_validator(mode="after")
    def require_evidence_for_known_value(self) -> "ConditionObservation":
        if self.value is not TruthValue.UNKNOWN and (
            not self.evidence_ref or not self.evidence_ref.strip()
        ):
            raise ValueError("a known condition requires an evidence reference")
        return self


class BranchDecision(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    condition_id: str
    value: TruthValue
    evidence_ref: str | None
    selected_target_id: str | None


def decide_branch(
    observation: ConditionObservation, branches: Sequence[ConditionalExit]
) -> BranchDecision:
    exits = [branch for branch in branches if branch.condition_id == observation.condition_id]
    if not exits:
        raise ValueError(f"no authored exits for condition {observation.condition_id}")
    if observation.value is TruthValue.UNKNOWN:
        target = None
    else:
        matching = [
            branch.target_id
            for branch in exits
            if branch.when_true is (observation.value is TruthValue.TRUE)
        ]
        if len(matching) != 1:
            raise ValueError(f"condition {observation.condition_id} needs one matching exit")
        target = matching[0]
    return BranchDecision(
        condition_id=observation.condition_id,
        value=observation.value,
        evidence_ref=observation.evidence_ref,
        selected_target_id=target,
    )
