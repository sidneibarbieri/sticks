"""Dispatch one conditional exit after recording its observed basis."""

from collections.abc import Callable, Sequence
from pathlib import Path

from contracts.branch_decision import (
    BranchDecision,
    ConditionalExit,
    ConditionObservation,
    decide_branch,
)


def execute_conditional_step(
    condition_id: str,
    exits: Sequence[ConditionalExit],
    *,
    observe: Callable[[], ConditionObservation],
    dispatch: Callable[[str], None],
    decision_path: Path,
) -> BranchDecision:
    """Retain the decision before dispatch; completion is not effect evidence."""
    observation = observe()
    if observation.condition_id != condition_id:
        raise ValueError("observation belongs to a different condition")
    decision = decide_branch(observation, exits)
    with decision_path.open("x", encoding="utf-8") as retained:
        retained.write(decision.model_dump_json(indent=2) + "\n")
    if decision.selected_target_id is not None:
        dispatch(decision.selected_target_id)
    return decision
