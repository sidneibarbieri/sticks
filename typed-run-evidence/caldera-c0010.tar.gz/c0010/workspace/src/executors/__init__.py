# STICKS abilities registry package
