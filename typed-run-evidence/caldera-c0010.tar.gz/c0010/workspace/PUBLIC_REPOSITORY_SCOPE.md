# Public Repository Scope

The stable public contract is:

- `run_review_check.sh` and `scripts/reproduce.py`;
- the controlled-comparison and blinded-oracle contracts and validators;
- compiler, concretization, contract, and evaluation modules under `src/`;
- pinned inputs under `data/stix/` and `data/concretization/`;
- frozen records under `release/experiments/` and `release/plans/`;
- the claim ledger, SHA-256 integrity manifest, and linked tests.

Local configuration, credentials, private keys, generated host traces, caches,
VM state, runtime evidence, migration records, manuscript-administration files,
and derived manuscript PDFs are excluded from a public package. In particular,
`paper/build_artifacts/main.pdf` is a local LaTeX build product rather than
reviewer-facing artifact evidence.

Pinned third-party corpora remain byte-preserved. Incidental publication names inside those source
records are corpus content, not artifact targeting; authored code, documentation, paths, and runtime
messages remain evaluation-channel neutral.

`measurement/sut/`, `lab/`, and older runners are secondary compatibility
material. They support no registered property unless the ledger links them.
