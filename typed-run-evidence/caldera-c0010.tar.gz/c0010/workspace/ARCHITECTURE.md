# Architecture

The primary pipeline has five deterministic stages:

1. compile a pinned ATT&CK-in-STIX campaign into a typed procedural plan;
2. retrieve and enumerate all finite catalog candidates for each technique;
3. admit candidates against an explicitly scoped fact state;
4. emit a concretized plan with binding provenance and semantic hashes;
5. certify selected executions against declared effects and evidence predicates.

Proposal and admission are separate. A human or model may propose a template,
but only the deterministic verifier can commit it. Unknown templates, wrong
techniques, and unavailable bindings fail admission and leave the committed
plan unchanged.

The optional controlled-comparison layer preserves the same separation. Arm-specific adapters emit
a common hash-bound proposal record. A distinct transition removes the arm label before the shared
admission oracle runs, while a private assignment record permits later reconciliation. Complete run
accounting treats success, failure, and unsupported execution as disjoint terminal states. This
layer does not alter the primary concretization algorithm or imply that the comparison was run.

Earlier campaign runners, SUT profiles, and VM/container helpers are retained
as a secondary compatibility layer. They are not dependencies of the primary
evidence path and do not establish historical campaign replay.
