#!/bin/sh
echo 'STICKS benign staged tool'
