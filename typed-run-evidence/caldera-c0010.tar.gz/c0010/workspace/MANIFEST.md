# Manifest

## Primary

- `run_review_check.sh`
- `scripts/reproduce.py`, `scripts/verify_claims.py`, and `scripts/check_public_surface.py`
- `CONTROLLED_COMPARISON.md`, `scripts/validate_controlled_comparison.py`, and
  `scripts/evaluate_blind_oracle.py`
- `src/compilers/`, `src/concretization/`, `src/contracts/`, and `src/evaluation/`
- `data/stix/` and `data/concretization/`
- `release/plans/`, `release/experiments/`, and `release/claims/`
- `tests/`

## Secondary

- `measurement/sut/`
- `lab/`
- `artifact/`
- older campaign runners and SUT profiles

Secondary material supports no manuscript claim unless the ledger links it.
The controlled-comparison contract is primary reusable infrastructure but supports no result until
a frozen experiment and its complete evidence ledger are registered.
