# Reproducibility Contract

The reproducible unit is a registered property in
`release/claims/ledger.json`. Each non-blocked property names its population,
support type, evidence files, tests, permitted wording, and forbidden wording.
`scripts/reproduce.py` rebuilds the evidence from tracked inputs and verifies
the pinned SHA-256 manifest.

The primary path requires Python 3.11 or later and `requirements.txt`. It needs
no network after dependency installation and no API key, container runtime,
hypervisor, or external service.

The primary path is the **fast review mode**. It deliberately excludes live
laboratory execution. A strict QEMU experiment requires separately prepared
offline runtime images: its frozen profile must bind the Python lock, the C0045
study and schedule, VM definitions, every provisioning input, a prepared
runtime manifest for Caldera, attacker, and target (including each guest
inventory and image fingerprint),
`vagrant-qemu`, the selected box identity, and the local image-tree fingerprint.
The former v1 profile is retired because it allowed guest provisioning to
download packages during a claimed strict run. The v7 profile is also
deliberately fail-closed after runtime-source drift. The current v16 profile
uses prepared-runtime manifest v8 and records an audit-visible transitive
execution-source inventory in addition to image and configuration bindings.
Its role boxes use the `libvirt` box format consumed by `vagrant-qemu`, while
the execution provider remains QEMU. A local 20-cell series completed with
distinct guest boots; the verified archive remains private until release review.
See
the two-mode table in `README.md` for command and claim limits.

Keep these populations separate:

1. trusted-catalog reach, recorded in `release/experiments/catalog_baseline/`;
2. contract-valid draft reach, rechecked from the frozen proposer calls in
   `release/experiments/stage2_authoring/`;
3. operational execution and observed effects in the selected laboratory runs.

The two Stage-2 runs named in `release/experiments/stage2_authoring/paper_runs.json`
are included so their recorded decisions can be checked. Later local runs do not
enter the package or manuscript automatically. The offline path rechecks their
decisions; it does not reproduce the model's raw responses. Their model tag was
mutable, and one run records a dirty source tree. They are exploratory evidence,
not a clean model-reproduction result or proof of executed draft behavior.

Retained VM and container experiments are secondary compatibility material.
Their results do not enter the property ledger unless named explicitly.
