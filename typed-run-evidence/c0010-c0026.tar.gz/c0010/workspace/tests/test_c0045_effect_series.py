"""The post-diagnostic C0045 series must not permit selective cell omission."""

import pytest

from runners.c0045_effect_series import C0045EffectSeries, load_c0045_effect_series


def test_series_has_five_fresh_boot_blocks_with_all_four_arms() -> None:
    series = load_c0045_effect_series()
    assert len(series.selected_cells) == 20
    assert series.arm_for("b1-treatment") == "treatment"
    assert series.arm_for("b5-controller_only") == "controller_only"
    assert series.prior_treatment_role == "diagnostic_excluded"


def test_series_rejects_missing_or_unselected_cells() -> None:
    series = load_c0045_effect_series()
    with pytest.raises(ValueError, match="frozen schedule"):
        series.arm_for("b6-treatment")
    with pytest.raises(ValueError, match="every arm"):
        C0045EffectSeries.model_validate(
            {**series.model_dump(), "selected_cells": series.selected_cells[:-1]}
        )
