"""A C0045 series cannot skip cells, reuse boots, or hide failed attempts."""

from pathlib import Path
from types import SimpleNamespace

import pytest

from runners.c0045_series_run import (
    C0045SeriesOutcome, retain_c0045_bootstrap_error, run_c0045_series_cell,
    verify_c0045_series_cell,
)


def _fake_run(output_dir: Path, name: str, boot_id: str, status: str):
    root = output_dir / name
    root.mkdir(parents=True, exist_ok=False)
    (root / "summary.json").write_text("{}", encoding="utf-8")
    report = SimpleNamespace(
        run_id=name, status=status,
        bootstrap=SimpleNamespace(scope=SimpleNamespace(epoch=boot_id)),
    )
    return report, root


def test_series_requires_selected_order_and_retains_runner_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    with pytest.raises(ValueError, match="Prior C0045 series cell is incomplete"):
        run_c0045_series_cell("b1-busy", tmp_path)

    def fail_treatment(_output_dir):
        raise RuntimeError("lab not ready")

    monkeypatch.setattr(
        "runners.c0045_series_run.run_c0045_treatment", fail_treatment
    )
    with pytest.raises(RuntimeError, match="lab not ready"):
        run_c0045_series_cell("b1-treatment", tmp_path)
    root = tmp_path / "c0045-series-v1/b1-treatment"
    error = C0045SeriesOutcome.model_validate_json(
        (root / "outcome.json").read_bytes()
    )
    assert error.status == "runner_error" and error.error_type == "RuntimeError"
    assert verify_c0045_series_cell(tmp_path, "b1-treatment") == error
    with pytest.raises(FileExistsError):
        run_c0045_series_cell("b1-treatment", tmp_path)


def test_series_retains_bootstrap_error_with_all_vm_states(tmp_path: Path) -> None:
    outcome = retain_c0045_bootstrap_error(
        "b1-treatment",
        tmp_path,
        RuntimeError("caldera unavailable"),
        {"caldera": "running", "attacker": "running", "target-linux-1": "running"},
    )

    assert outcome.status == "runner_error"
    assert outcome.bootstrap_diagnostic is not None
    assert verify_c0045_series_cell(tmp_path, "b1-treatment") == outcome


def test_series_joins_run_and_rejects_reused_boot(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    treatment, treatment_root = _fake_run(tmp_path, "treatment-run", "boot-1", "observed")
    monkeypatch.setattr(
        "runners.c0045_series_run.run_c0045_treatment",
        lambda _output_dir: (treatment, treatment_root),
    )
    monkeypatch.setattr(
        "runners.c0045_series_run.verify_c0045_treatment", lambda _root: treatment
    )
    first, _ = run_c0045_series_cell("b1-treatment", tmp_path)
    assert first.status == "observed"
    assert verify_c0045_series_cell(tmp_path, "b1-treatment") == first

    control, control_root = _fake_run(tmp_path, "control-run", "boot-1", "measured")
    monkeypatch.setattr(
        "runners.c0045_series_run.run_c0045_control",
        lambda _cell_id, _output_dir: (control, control_root),
    )
    monkeypatch.setattr(
        "runners.c0045_series_run.verify_c0045_control", lambda _root: control
    )
    with pytest.raises(ValueError, match="reused a prior guest boot"):
        run_c0045_series_cell("b1-busy", tmp_path)
    invalid = verify_c0045_series_cell(tmp_path, "b1-busy")
    assert invalid.status == "boot_reused" and invalid.boot_id == "boot-1"
    with pytest.raises(ValueError, match="reused a prior guest boot"):
        run_c0045_series_cell("b1-idle", tmp_path)


def test_series_detects_tampered_outcome(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    treatment, treatment_root = _fake_run(tmp_path, "treatment-run", "boot-1", "observed")
    monkeypatch.setattr(
        "runners.c0045_series_run.run_c0045_treatment",
        lambda _output_dir: (treatment, treatment_root),
    )
    monkeypatch.setattr(
        "runners.c0045_series_run.verify_c0045_treatment", lambda _root: treatment
    )
    run_c0045_series_cell("b1-treatment", tmp_path)
    (treatment_root / "summary.json").write_text('{"changed":true}', encoding="utf-8")
    with pytest.raises(ValueError, match="summary differs"):
        verify_c0045_series_cell(tmp_path, "b1-treatment")


def test_series_rejects_arm_status_mismatch() -> None:
    with pytest.raises(ValueError, match="contradicts its selected arm"):
        C0045SeriesOutcome.model_validate({
            "schema_version": "c0045-series-selection/v1",
            "cell_id": "b1-busy", "arm": "busy", "order_index": 1,
            "source_study_sha256": "a" * 64,
            "series_sha256": "b" * 64,
            "status": "observed", "run_id": "run", "run_relative_path": "run",
            "boot_id": "boot", "summary_sha256": "c" * 64,
        })
