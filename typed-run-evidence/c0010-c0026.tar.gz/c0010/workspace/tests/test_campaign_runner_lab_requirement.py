from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parent.parent
RUNNER_PATH = PROJECT_ROOT / "src" / "runners" / "campaign_runner.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("campaign_runner_lab", RUNNER_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_campaign_evidence_requires_a_reachable_lab(monkeypatch, tmp_path) -> None:
    module = _load_module()
    monkeypatch.setattr(module, "detect_lab_infrastructure", lambda _: "")
    runner = module.UnifiedCampaignRunner(
        "0.c0011", tmp_path, require_lab=True
    )

    with pytest.raises(RuntimeError, match="Refusing to create campaign/SUT evidence"):
        runner.run()
