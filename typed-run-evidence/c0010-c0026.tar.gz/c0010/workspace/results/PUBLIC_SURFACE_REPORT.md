# Public Surface Report

- Status: `clean`

## Missing Required Paths

- None

## Sensitive Paths Present

- None

## Forbidden Staged Paths Present

- None

## Forbidden Text Hits

- None

## Sensitive Text Hits

- None

## Sensitive Files Present

- None

## README Metric Mismatches

- None

## Local Runtime Artifacts Present

- None

## Ignored Local Runtime Artifacts

- None

## Structure Smells Present

- None

## Ignored Structure Smells

- None