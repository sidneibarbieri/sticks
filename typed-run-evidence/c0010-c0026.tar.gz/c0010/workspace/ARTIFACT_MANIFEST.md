# Public Artifact Manifest

- Repository URL is supplied by the distribution channel.

## Primary evidence path

- `scripts/reproduce.py` regenerates every registered experiment record.
- `release/claims/ledger.json` maps each property to evidence and tests.
- `release/claims/evidence_sha256.json` freezes evidence and test hashes.
- `PUBLIC_TREE_SHA256.json` freezes every shipped file outside declared runtime output.
- `run_review_check.sh` runs regeneration, integrity checks, hygiene, and tests.

## Secondary material

- `measurement/sut/` and the VM/lab helpers preserve earlier experiments.
- Run the older measurement gate with `bash run_review_check.sh --legacy`.
- That material is not evidence for a registered property unless the ledger links it.

## Excluded

Local VM state, caches, provider configuration, credentials, private keys,
unselected runtime evidence, superseded result reports, and derived
manuscript PDFs are excluded. In particular, `paper/build_artifacts/main.pdf` is
not reviewer-facing artifact evidence.
