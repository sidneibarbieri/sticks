#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() {
  cat <<'EOF'
Usage:
  bash artifact/run.sh [--help]

Runs the canonical VM-backed STICKS campaign and regenerates its tables.
This command materializes infrastructure. Use --help to inspect it without
creating VMs or changing experiment state.
EOF
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  usage
  exit 0
fi
if [[ $# -ne 0 ]]; then
  usage >&2
  exit 2
fi

cd "$ROOT_DIR"
source "$ROOT_DIR/scripts/python_env.sh"
PYTHON_BIN="$(sticks_resolve_python "$ROOT_DIR" "$ROOT_DIR/requirements.txt")"

export PYTHONPATH="$ROOT_DIR/src${PYTHONPATH:+:$PYTHONPATH}"

echo "[artifact/run] executing canonical VM-backed campaign..."
"$PYTHON_BIN" scripts/run_lab_campaign.py \
  --campaign 0.c0011 \
  --persist-derived-state

echo "[artifact/run] regenerating tables..."
"$PYTHON_BIN" scripts/generate_tables.py

echo "[artifact/run] done"
