# Public Repository Scope

The stable contract is `run_review_check.sh`, `scripts/reproduce.py`, the
compiler/concretization/contract/evaluation modules, pinned inputs under
`data/`, frozen records under `release/experiments`, the claim ledger and
integrity manifest, and linked tests.

`CONTROLLED_COMPARISON.md` and its validators define an optional reusable
experiment contract. They support no property until a frozen run set is
registered in the claim ledger.

Local configuration, credentials, private keys, generated host traces, caches,
VM state, unselected runtime evidence, manuscript-administration files, and derived
manuscript PDFs are excluded.
Pinned third-party corpora remain byte-preserved. Incidental publication names
inside source records are corpus content, not artifact targeting; authored
surfaces remain evaluation-channel neutral.
`measurement/sut`, `lab`, and older runners are secondary compatibility material.
